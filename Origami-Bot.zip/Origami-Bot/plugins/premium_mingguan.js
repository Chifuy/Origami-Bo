let handler = async m => await conn.sendButton(m.chat, `
╭─「 Premium • Non Pulsa 」
│ • 7 Hari => 7K [DANA/GoPay]
│ • 14 Hari => 13K [DANA/GoPay]
╰────

╭─「 Premium • Pulsa 」
│ • 7 Hari => 10K [Indosat/Smartfren]
│ • 14 Hari => 20K [Indosat/Samartfren]
╰────

*NOTE:*
Silahkan Chat Owner Jika Ingin Premium
`, '© Origami-Bot', 'OWNER', '!owner', { quoted: m })

handler.command = /^premharian$/i

module.exports = handler
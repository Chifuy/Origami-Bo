let fetch = require('node-fetch')

let handler = async (m, { conn }) => {
 conn.fakeReply(m.chat, 'Searching...','0@s.whatsapp.net','Sabar Yah Kak :/')
 await conn.sendFile(m.chat, global.API('xteam', '/randomimage/ass', {}, 'APIKEY'), 'ass.png', ' Mau Ngocok Ya? Hati-hati Ketahuan', m, false, {thumbnail: Buffer.alloc(0) })
}
handler.help = ['ass']
handler.tags = ['weeaboo']
handler.command = /^ass$/i
handler.owner = false
handler.mods = false
handler.premium = true
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null
handler.limit = false

module.exports = handler
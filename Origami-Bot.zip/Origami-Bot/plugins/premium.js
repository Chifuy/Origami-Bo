let handler = async m => await conn.send2Button(m.chat, `
╭─「 Premium • Non Pulsa 」
│ • DANA => 25K [Permanen]
│ • GoPay => 25K [Permanen]
╰────

╭─「 Premium • Pulsa 」
│ • Indosat => 40K [Permanen]
│ • Smartfren => 40K [Permanen]
╰────

*NOTE:*
Silahkan Chat Owner Jika Ingin Premium
`.trim(), '© Origami-Bot', 'PREM HARIAN', '!premharian', 'OWNER', '!owner', { quoted: m})
handler.help = ['premium']
handler.tags = ['info']                                  
handler.command = /^(premium|prem)$/i

module.exports = handler
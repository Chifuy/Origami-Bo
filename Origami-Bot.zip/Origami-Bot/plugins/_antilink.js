let handler = m => m

let linkRegex = /chat.whatsapp.com\/(?:invite\/)?([0-9A-Za-z]{20,24})/i
handler.before = function (m, { isAdmin, isBotAdmin }) {
  if (m.isBaileys && m.fromMe) return true
  let chat = global.db.data.chats[m.chat]
  let isGroupLink = linkRegex.exec(m.text)

  if (chat.antiLink && isGroupLink) {
    this.sendButton(m.chat, `「 Anti Link Detected 」\n${isBotAdmin ? '' : '\n\nBukan admin jadi gabisa kick t_t'}\n\nMaaf, Anda Akan Dikick!`, '© Origami-Bot', 'OFF ANTI LINK', '!disable antilink', { quoted: m })
    if (global.opts['restrict']) {
      if (isAdmin || !isBotAdmin) return true
       this.groupRemove(m.chat, [m.sender])
    }
  }
  return true
}

module.exports = handler
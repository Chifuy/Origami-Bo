let handler = async m => m.reply(`
*GROUP OFFIC:*
https://chat.whatsapp.com/GFmbKrJHKGM7hXMYyzOL0l

*SCRIPT ORI:*
https://github.com/Nurutomo/wabot-aq

`.trim())
handler.command = /^linksc$/i

module.exports = handler
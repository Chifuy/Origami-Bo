let handler = async (m, { conn, isPrems, text }) => {
    let yoi = Math.floor(Math.random() * 500)
    let yoih = Math.floor(Math.random() * 550)
    let exp = Math.floor(Math.random() * 700)
global.db.data.users[m.sender].buah += isPrems ? yoih : yoi
global.db.data.users[m.sender].exp += exp
await conn.sendButton(m.chat, `
[ 🎰 SLOTS ]
${pickRandom(['🍇','🍉','🍎','🍌','🍋','🍊','🍓','🍒','🍍','🍈','🥑','🍐','🥝','7️⃣'])} | ${pickRandom(['🍇','🍉','🍎','🍌','🍋','🍊','🍓','🍒','🍍','🍈','🥑','🍐','🥝','7️⃣'])} | ${pickRandom(['🍇','🍉','🍎','🍌','🍋','🍊','🍓','🍒','🍍','🍈','🥑','🍐','🥝','7️⃣'])}
${pickRandom(['🍇','🍉','🍎','🍌','🍋','🍊','🍓','🍒','🍍','🍈','🥑','🍐','🥝','7️⃣'])} | ${pickRandom(['🍇','🍉','🍎','🍌','🍋','🍊','🍓','🍒','🍍','🍈','🥑','🍐','🥝','7️⃣'])} | ${pickRandom(['🍇','🍉','🍎','🍌','🍋','🍊','🍓','🍒','🍍','🍈','🥑','🍐','🥝','7️⃣'])} <==
${pickRandom(['🍇','🍉','🍎','🍌','🍋','🍊','🍓','🍒','🍍','🍈','🥑','🍐','🥝','7️⃣'])} | ${pickRandom(['🍇','🍉','🍎','🍌','🍋','🍊','🍓','🍒','🍍','🍈','🥑','🍐','🥝','7️⃣'])} | ${pickRandom(['🍇','🍉','🍎','🍌','🍋','🍊','🍓','🍒','🍍','🍈','🥑','🍐','🥝','7️⃣'])}
[ 🎰 SLOTS ]

*+${exp}* *️⃣Exp
*+${isPrems ? yoih : yoi}* 🍑Fruit 
`.trim(), '© Origami-Bot', 'NEXT 🎰', '!slot', { quoted: m })
}
handler.help = ['slot']
handler.tags = ['game']
handler.command = /^slot/i
handler.limit = 2

module.exports = handler

function pickRandom(list) {
  return list[Math.floor(Math.random() * list.length)]
}

let handler = async m => await conn.send2Button(m.chat, `
╭─「 Donasi • Pulsa 」
│ • Indosat [085747543536]
│ • Smartfren [088232733050]
╰────

╭─「 Donasi • Non Pulsa 」
│ • OVO,DANA,GoPay [085747543536]
│ • ShopeePay
╰────

Thanks
`.trim(), '© Origami-Bot', 'PREMIUM', '!prem', 'SEWA BOT', '!sewa', { quoted: m}) // Tambah sendiri kalo mau
handler.help = ['donasi']
handler.tags = ['info']
handler.command = /^dona(te|si)$/i

module.exports = handler
